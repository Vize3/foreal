const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://Vizeee:yLM9$J.9kdQkX4f@cluster0.gqc0w.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
    .then(() => {
        console.log('Conectado a la base de datos');
    })
    .catch((err) => {
        console.error('Error al conectar a la base de datos', err);
    });

const productSchema = new mongoose.Schema({
    name: String,
    price: Number,
    imageUrl: String,
    link: String,
});

const Product = mongoose.model('Product', productSchema);

const products = [
    {
        name: 'Producto1',
        price: 20,
        imageUrl: 'https://example.com/product1.jpg',
        link: 'https://example.com/product1',
    },
    {
        name: 'Producto2',
        price: 30,
        imageUrl: 'https://example.com/product2.jpg',
        link: 'https://example.com/product2',
    },
    {
        name: 'Producto3',
        price: 40,
        imageUrl: 'https://example.com/product3.jpg',
        link: 'https://example.com/product3',
    },
    {
        name: 'Producto4',
        price: 50,
        imageUrl: 'https://example.com/producto4.jpg',
        link: 'https://example.com/product4',
    },
    {
        name: 'Product5',
        price: 60,
        imageUrl: 'https://example.com/producto5.jpg',
        link: 'https://example.com/product5',
    },
];

async function updateProducts() {
    try {
        await Product.deleteMany({});
        console.log('Productos antiguos eliminados');

        await Product.insertMany(products);
        console.log('Productos nuevos añadidos');
    } catch (err) {
        console.error('Error al actualizar productos', err);
    } finally {
        mongoose.connection.close();
    }
}

updateProducts();
