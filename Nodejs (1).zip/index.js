const { Client, GatewayIntentBits, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');
const mongoose = require('mongoose');

const keep_alive = require('./keep_alive.js')


const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
});

mongoose.connect('mongodb+srv://Vizeee:yLM9$J.9kdQkX4f@cluster0.gqc0w.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
    .then(() => {
        console.log('Conectado a la base de datos');
    })
    .catch((err) => {
        console.error('Error al conectar a la base de datos', err);
    });

// Definir el esquema y modelo de usuario
const userSchema = new mongoose.Schema({
    userId: String,
    balance: { type: Number, default: 0 },
});

const User = mongoose.model('User', userSchema);

// Definir el esquema y modelo de producto
const productSchema = new mongoose.Schema({
    name: String,
    price: Number,
    imageUrl: String,
    link: String,
});

const Product = mongoose.model('Product', productSchema);

client.once('ready', async () => {
    console.log('Bot is online!');

    // Obtener el canal de tienda
    const shopChannel = client.channels.cache.find(channel => channel.name === 'shop');
    if (!shopChannel) {
        console.error('Canal de tienda no encontrado');
        return;
    }

    // Eliminar mensajes anteriores en el canal de tienda
    const fetchedMessages = await shopChannel.messages.fetch({ limit: 100 });
    shopChannel.bulkDelete(fetchedMessages);

    // Obtener productos de la base de datos
    const products = await Product.find();
    if (products.length === 0) {
        console.error('No se encontraron productos');
        return;
    }

    // Crear y enviar un embed separado para cada producto
    for (const product of products) {
        const embed = new EmbedBuilder()
            .setTitle(product.name)
            .setDescription(`Price: ${product.price} coins`)
            .setImage(product.imageUrl);

        const button = new ButtonBuilder()
            .setLabel('Buy')
            .setStyle(ButtonStyle.Success)
            .setCustomId(`buy_${product.name}`);

        const row = new ActionRowBuilder().addComponents(button);

        await shopChannel.send({ embeds: [embed], components: [row] });
    }
});

client.on('messageCreate', async message => {
    if (message.content.startsWith('!give')) {
        const [command, userId, amount] = message.content.split(' ');

        if (!userId || !amount) {
            message.channel.send('Por favor, proporciona un ID de usuario y una cantidad.');
            return;
        }

        const user = await User.findOne({ userId });

        if (!user) {
            const newUser = new User({ userId, balance: parseInt(amount) });
            await newUser.save();
        } else {
            user.balance += parseInt(amount);
            await user.save();
        }

        message.channel.send(` ${amount} a <@${userId}>`);
    }

    if (message.content.startsWith('!balance')) {
        const user = await User.findOne({ userId: message.author.id });

        if (!user) {
            message.channel.send('No tienes balance.');
        } else {
            message.channel.send(`Tu balance es ${user.balance} coins.`);
        }
    }

    if (message.content.startsWith('!shop')) {
        // Obtener productos de la base de datos
        const products = await Product.find();
        if (products.length === 0) {
            message.channel.send('No hay productos disponibles.');
            return;
        }

        // Crear y enviar un embed separado para cada producto
        for (const product of products) {
            const embed = new EmbedBuilder()
                .setTitle(product.name)
                .setDescription(`Price: ${product.price} coins`)
                .setImage(product.imageUrl);

            const button = new ButtonBuilder()
                .setLabel('Buy')
                .setStyle(ButtonStyle.Success)
                .setCustomId(`buy_${product.name}`);

            const row = new ActionRowBuilder().addComponents(button);

            await message.channel.send({ embeds: [embed], components: [row] });
        }
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    const productName = interaction.customId.split('_')[1];
    const product = await Product.findOne({ name: productName });
    const user = await User.findOne({ userId: interaction.user.id });

    if (!product || !user || user.balance < product.price) {
        interaction.reply({ content: 'Insufficiente balance.', ephemeral: true });
        return;
    }

    user.balance -= product.price;
    await user.save();

    interaction.reply({ content: `Compraste ${product.name} por ${product.price} coins.`, ephemeral: true });

    // Enviar DM con el link de la compra
    const dmEmbed = new EmbedBuilder()
        .setTitle('Confirmacion')
        .setDescription(`Compraste ${product.name}. Aqui esta tu link de tu compra: ${product.link}`)
        .setImage(product.imageUrl);

    interaction.user.send({ embeds: [dmEmbed] });
});

client.login('MTI3MTI2NTA5MDEyMDg0NzQ4MA.GxPxfl._I46oFHL_q-Q07I4EJxzCc-jqlvF7cgdcWR9TI');
